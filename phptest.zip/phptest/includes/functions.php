<?php 

/*function fileCreating() {
	$file = fopen("normal.txt", "w");
	if(empty($myfile)) {
		$text = "This is readme file,rate it! 1-5";
		fwrite($file, $text);
	} else {
		echo "You already have that file!";
	}
}
fileCreating();*/


/*function connection() {
	$user = "root";
	$password = "";
	$host = "localhost";
	$database = "sakila";
	$conn = mysqli_connect($host, $user, $password, $database);
	if (!$conn) {
		die("Failed to connect to database " . mysqli_error());
	} else {
		echo "You have connected to database successfully ! <br>";
	}
}
connection();*/

/*function changedb() {
	$user = "root";
	$password = "";
	$host = "localhost";
	$database = "users";
	$conn = mysqli_connect($host, $user, $password, $database);
	if($database == "users") {
		mysqli_select_db($conn, "sakila");
	} else {
		echo "Database currently used is : " . $database . "<br>";
	}
}

changedb();
*/

function dircon() {
	$dir = "../";
	if (is_dir($dir)) {
		if ($dh = opendir($dir)) {
			while (($file = readdir($dh)) !== false) {
				echo "Filename :" . $file . "<br>";
			}
		closedir($dh);
		}
	}
}

// 	



?>