<?php 

include 'route.php';

$route = new Route();

$route->add('/');
$route->add('/contact');
$route->add('/register');
$route->add('/products');
$route->add('/login');

echo '<pre>';	 
print_r($route);

$route->submit(); 	

 ?>