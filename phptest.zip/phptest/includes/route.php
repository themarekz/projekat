<?php 

class Route {
	
	private $_uri = array();

	public function add($uri) {
		$this->_uri[] = $uri;
	}
	public function submit() {

		echo $uriGetParam = isset($_GET['uri']) ? $_GET['uri'] : '/';
		echo '<br />';
		foreach ($this->_uri as $Key => $Value) {
			echo $value;
			if (preg_match("#^$value$#", $uriGetParam)) {
				echo 'match!';
			}
		}

	}
}


 ?>