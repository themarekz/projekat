/*SELECT*/

SELECT * FROM `actor`;
SELECT `actor_id` FROM `actor`;
SELECT `first_name` FROM `actor`;
SELECT `last_name` FROM `actor`;
SELECT `last_update` FROM `actor`;

SELECT DISTINCT `first_name` FROM `actor`;
SELECT * FROM `address`;
SELECT `address_id` FROM `address`;
SELECT DISTINCT `address_id` FROM `address`;
SELECT COUNT(DISTINCT first_name) FROM customer;
SHOW COLUMNS FROM rental; /*prikazivanje kolona iz tabele*/
SELECT `rental_id` FROM `rental` WHERE rental_id=10;
SHOW COLUMNS FROM actor;
SELECT first_name FROM actor WHERE first_name='JOHNNY';

/*AND OR NOT*/

SELECT country FROM country WHERE country='Germany' AND city='Norway';
SELECT * FROM country WHERE NOT country='Yugoslavia';


/*ORDER BY*/

SELECT country FROM country ORDER BY country;
SELECT country FROM country ORDER BY country DESC;
SELECT name FROM language ORDER BY name;
SELECT name FROM language ORDER BY name ASC;
SELECT name FROM language ORDER BY name DESC;
SELECT name FROM language WHERE name='Mandarin' AND name='French';
SELECT * FROM payment ORDER BY payment_id DESC, rental_id ASC;

/*INSERT INTO TABLE*/

INSERT INTO city('city_id', 'city') VALUES ('11', 'Belgrade');

/* NULL */

SELECT film_id, category_id, last_update FROM film_category WHERE category_id IS NULL;
SELECT ID, name, address FROM customer_list WHERE address IS NULL;
SELECT ID, name, address FROM customer_list WHERE address IS NOT NULL LIMIT 10;

/*UPDATE */

UPDATE customer SET first_name='Marko', last_name='Markovic', email='themarekz@live.com' WHERE customer_id=1;
UPDATE city SET city_id=1, city='Belgrade', country_id=87 WHERE city_id=1;

DELETE FROM actor WHERE first_name='PENELOPE';

UPDATE city SET city='Nis' WHERE city_id=372; 

/*DELETE*/

DELETE FROM city WHERE city_id='2';

/*MIN,MAX*/

SELECT MIN(rental_id) FROM payment;
SELECT MAX(rentaL_id) FROM payment;
SELECT MAX(total_sales) AS sales FROM sales_by_film_category;
SELECT MAX(total_sales) AS ukupno FROM sales_by_film_category;
SELECT * FROM sales_by_film_category ORDER BY total_sales ASC;
SELECT MIN(total_sales) AND MAX(total_sales) as ukupno FROM sales_by_film_category;
SELECT category FROM sales_by_film_category ORDER BY category ASC;
SELECT category AS kategorija FROM sales_by_film_category;
SELECT category from sales_by_film_category;

/*AVG(),COUNT(),SUM()*/

SELECT COUNT(total_sales) FROM sales_by_film_category;
SELECT COUNT(total_sales) AS UKUPNO FROM sales_by_film_category;
SELECT AVG(total_sales) AS Average FROM sales_by_film_category;
SELECT SUM(total_sales) FROM sales_by_film_category;
SELECT SUM(total_sales) AS TOTAL_SUM FROM sales_by_film_category;
SELECT COUNT(rental_id) AS TOTAL FROM payment;
SELECT SUM(rental_id) FROM payment;
SELECT AVG(rental_id) AS PROSECNO FROM payment;

/*LIKE*/

/*ENDING WITH CHARACTER*/
SELECT * FROM actor WHERE first_name LIKE '%m';
SELECT COUNT(last_name) FROM actor WHERE last_name LIKE '%S';

/*BEGINNING WITH CHARACHTER*/

SELECT * FROM actor WHERE first_name LIKE 'M%';
SELECT * FROM actor WHERE first_name LIKE 'SANDRA%';
SELECT * FROM city WHERE 
SELECT COUNT(first_name) FROM city WHERE first_name LIKE 'S%';
SELECT COUNT(first_name) FROM city AS grad WHERE first_name LIKE 'S%';

/*WILDCARD*/

SELECT * FROM city WHERE city LIKE 'ber%';
SELECT * FROM city WHERE city LIKE '%es%';
UPDATE city SET city_id=91, city='Borca' WHERE city_id=91; 
SELECT * FROM city WHERE city LIKE '_erlin';

/*IN*/

SELECT * FROM city WHERE city IN('Berlin', 'Borca', 'Berghamo'); /*vise vrednosti*/
SELECT SUM(price) AS Cena FROM nicer_but_slower_film_list;
SELECT AVG(price) AS Prosecno FROM nicer_but_slower_film_list;
SELECT * FROM nicer_but_slower_film_list AS Specified_movies WHERE title IN('ACADEMY DINOSAUR', 'AGENT TRUMAN' , 'ALABAMA DEVIL');
SELECT AVG(price) AS Prosecno FROM nicer_but_slower_film_list WHERE title IN('ACADEMY DINOSAUR', 'AGENT TRUMAN' , 'ALABAMA DEVIL');
SELECT * FROM actor WHERE first_name IN('PENELOPE', 'BETTE', 'CHRISTIAN', 'JENNIFER');
SELECT * FROM actor WHERE first_name LIKE 'EN%';
UPDATE address_id FROM customer WHERE address_id=5; 
SELECT * FROM customer WHERE first_name IN (SELECT actor FROM actor);

/*BETWEEN*/

SELECT COUNT(total_sales) AS sales FROM sales_by_film_category 
WHERE total_sales BETWEEN 3417 AND 3950;

SELECT COUNT(total_sales) AS sales FROM sales_by_film_category 
WHERE total_sales NOT BETWEEN 3417 AND 4150;

SELECT SUM(total_sales) AS suma FROM sales_by_film_category 
WHERE total_sales BETWEEN 3417 AND 5000;

SELECT * FROM film_list WHERE name BETWEEN 'English' AND 'German' ORDER BY ASC;
SELECT COUNT(payment_id) FROM payment;

SELECT * FROM payment WHERE (payment_id BETWEEN 1 AND 16047) 
AND NOT rental_id BETWEEN 500 AND 1400 ORDER BY ASC;  

/*INNER JOIN*/ 
SELECT actor.first_name , actor.last_name
FROM customer 
INNER JOIN actor 
ON customer.first_name = actor.last_name;

SELECT actor.customer_id, actor.first_name
FROM customer
INNER JOIN actor
ON customer.actor_id = customer.customer_id LIMIT 5;

SELECT customer.first_name , customer.last_name 
FROM customer 
INNER JOIN actor
ON actor.first_name = actor.last_name;

SELECT customer.first_name , customer.last_name
FROM actor
INNER JOIN customer
ON actor.first_name = actor.last_name;

-- SELECT kolona
-- FROM tabela1
-- INNER JOIN tabela2
-- ON tabela1.kolona=tabela2.kolona

SELECT film.film_id
FROM film_category
INNER JOIN film 
ON film_category.film_id;

SELECT COUNT(film_category) AS ukupno FROM film_category;

/*LEFT JOIN*/

SELECT customer.first_name, customer_list.id
FROM customer
LEFT JOIN customer_list
ON customer.first_name = customer_list.id
LIMIT 5;

SELECT customer.first_name, customer_list.address
FROM customer
LEFT JOIN customer_list
ON customer.first_name = customer_list.address;

SELECT * FROM customer ORDER BY customer_id ASC LIMIT 5;
SELECT * FROM customer_list ORDER BY id ASC LIMIT 5;

/*UPDATE customer SET first_name='MARKO' WHERE first_name='JOVAN';*/
SELECT customer.first_name, customer_list.ID
FROM customer
LEFT JOIN customer_list
ON customer.ID = customer_list.first_name;

UPDATE customer SET first_name='PENELOPE'
WHERE first_name='MARKO';

UPDATE customer SET last_name='GUINESS' 
WHERE last_name='MARKOVIC';

/*FULL JOIN*/
/*zajebano mnogo*/
SELECT customer.first_name, actor.last_name 
FROM customer
FULL OUTER JOIN actor
ON customer.first_name = actor.last_name; 

/*SELF JOIN*/
SELECT B.first_name AS FirstName, B.last_name AS LastName,
A.first_name AS FirstName, A.last_name AS LastName
B.email, B.email
FROM Customer A, Customer B
WHERE A.customer_id < > B.customer_id
AND A.email = B.email;

/*UNION*/

SELECT * FROM customer LIMIT 5;
SELECT * FROM actor LIMIT 5;

SELECT first_name, last_name FROM customer
UNION
SELECT first_name, last_name FROM actor
ORDER BY first_name;

SELECT address_id FROM address 
UNION
select address_id FROM customer
ORDER BY address_id;

SELECT film_id, last_update FROM inventory 
UNION
SELECT film_id, last_update FROM film_category
ORDER BY film_id
LIMIT 100;

SELECT customer_id, rental_id, staff_id, last_update FROM payment
UNION
SELECT customer_id, rental_id, staff_id, last_update FROM payment 
ORDER BY customer_id
LIMIT 50;

SELECT country_id, last_update FROM city
UNION 
SELECT country_id, last_update FROM country
ORDER BY country_id
LIMIT 50;

/*GRUPISANJE REZULTATA GROUP BY*/
SELECT COUNT(customer_id), email
FROM customer
GROUP BY email
ORDER BY COUNT(customer_id) ASC LIMIT 50

SELECT COUNT(inventory_id), rental_id 
FROM rental
GROUP BY rentaL_id
ORDER BY COUNT(inventory_id), rentaL_id ASC LIMIT 50;

SELECT actor_id, first_name 
FROM actor
WHERE actor_id BETWEEN 1 AND 50 
GROUP BY last_name 
ORDER BY actor_id ASC;

SELECT sales_by_film_category.category, COUNT(sales_by_film_category.total_sales) FROM sales_by_film_category
LEFT JOIN sales_by_store 
ON sales_by_film_category.store = sales_by_store.manager
GROUP BY manager;

/*SELECT * FROM nicer_but_slower_film_list/**/

SELECT city_id, city 
FROM city
WHERE city LIKE 'C%'
GROUP BY country_id 
ORDER BY city ASC;

SELECT film_id, last_update 
FROM film_category 
WHERE film_id
GROUP BY film_id
ORDER BY film_id ASC;

/*HAVING*/

SELECT COUNT(inventory_id), customer_id 
FROM rental
GROUP BY customer_id 
HAVING COUNT(inventory_id) > 250
ORDER BY COUNT(inventory_id) ASC;

SELECT ID
FROM customer_list;
WHERE country LIKE 'S%'
GROUP BY ID
HAVING COUNT(ID) 
ORDER BY; ID ASC
LIMIT 10;

SELECT COUNT(customer_id), first_name 
FROM customer 
GROUP BY first_name 
HAVING COUNT(customer_id) > 5
ORDER BY COUNT(customer_id) DESC;

/*EXISTS*/

SELECT category_id 
FROM category 
WHERE EXISTS(SELECT film_id FROM film_category WHERE film_id BETWEEN 1 AND 20);

/*SELECT INTO - kopiranje podataka u novu tabelu sa pojedinacnim kolonama
ili sa celom tabelom*/

INSERT INTO customer 
SELECT inventory_id 
FROM rental;

INSERT INTO customer (customer_id, store_id)
SELECT ID,SID FROM customer_list;

/*KORISCENJE BAZE*/
CREATE DATABASE users;
DROP DATABASE korisnici;
DROP DATABASE users;

CREATE TABLE korisnici (
	person_id int, 
	first_name varchar(255),
	last_name varchar(255),
	email varchar(255),
	password int,
	address varchar(255),
	city varchar(255),
	country varchar(255)
);

INSERT INTO korisnici (person_id, first_name, last_name, email, address, city, country) VALUES (1, 'MARKO', 'MARKOVIC', 'THEMAREKZ@LIVE>COM', 'Borcanskih zrtava', 'Belgrade', 'Serbia');
INSERT INTO korisnici (person_id, first_name, last_name, email, address, city, country) VALUES (2, 'MARKO', 'CVIJANOVIC', 'MARKOCVIJANOVIC@GMAIL.COM', 'Nebojse Popovica', 'Belgrade', 'Serbia');
INSERT INTO korisnici (person_id, first_name, last_name, email, address, city, country) VALUES (3, 'ALDEN', 'BAJRAMI', 'MATICNAGRAFICKA@GMAIL.COM', 'Milutina Borisavljevica', 'Belgrade', 'Serbia');

DELETE FROM korisnici WHERE person_id=3;

CREATE TABLE omiljene_igrice (
	id_igrice int,
	naziv_igrice varchar(255),
	godina_izdavanja int,
	velicina_igrice int,
	izdavac varchar(255)
);

INSERT INTO omiljene_igrice (id_igrice, naziv_igrice, godina_izdavanja, velicina_igrice, izdavac) VALUES (1, 'MAX PAYNE 1', 2001, 555, 'ROCKSTAR GAMES');
INSERT INTO omiljene_igrice (id_igrice, naziv_igrice, godina_izdavanja, velicina_igrice, izdavac) VALUES (2, 'MAX PAYNE 2', 2003,1700, 'ROCKSTAR GAMES');
INSERT INTO omiljene_igrice (id_igrice, naziv_igrice, godina_izdavanja, velicina_igrice, izdavac) VALUES (3, 'MAX PAYNE 3', 2012, 35000, 'ROCKSTAR GAMES');

CREATE TABLE prodavanje (
	prodavnica varchar(255),
	menadzer varchar(255),
	ukupno int
);

INSERT INTO prodavanje(prodavnica, menadzer, ukupno) VALUES ('Julije Delere', 'BATA ZIVOJINOVIC', 350);

CREATE TABLE zanr(
	id int,
	zanr varchar(255),
	zadnje_azuriranje varchar(255)
);

INSERT INTO zanr(id, zanr, zadnje_azuriranje) VALUES (1, 'Shooting', '26/5/2018 17:22');
INSERT INTO zanr(id, zanr, zadnje_azuriranje) VALUES (2, 'Strategy', '26/5/2018 17:23');
INSERT INTO zanr(id, zanr, zadnje_azuriranje) VALUES (3, 'Survival', '26/5/2018 17:24');
INSERT INTO zanr(id, zanr, zadnje_azuriranje) VALUES (4, 'MMORPG', '26/5/2018 17:25');
INSERT INTO zanr(id, zanr, zadnje_azuriranje) VALUES (5, 'Action' , '28/5/2018 14:14');

ALTER TABLE prodavanje 
ADD test varchar(255);

ALTER TABLE prodavanje 
DROP COLUMN test; /*izbacivanje kolone iz */

CREATE TABLE automobili (
	id int NOT NULL,
	marka varchar(255) NOT NULL,
	model varchar(255) NOT NULL,
	drzava_porekla varchar(255) NOT NULL
);
DROP TABLE automobili;

INSERT INTO automobili(redni_broj, marka, model, drzava_porekla, godina_proizvodnje) VALUES (1, 'Mercedes-Benz', 'W126', 'Germany', '1979-1992');

ALTER TABLE automobili ALTER COLUMN redni_broj redni_broj int(35);

ALTER TABLE automobili DROP COLUMN redni_broj;
ALTER TABLE automobili ADD id int;

INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (1, 'Mercedes-Benz', 'W126', 'Germany');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (2, 'BMW', 'E46 320', 'Germany');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (3, 'Audi', 'RS4', 'Germany');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (5, 'SEAT', 'Leon', 'Spain');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (6, 'Renault', 'Clio', 'France');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (7, 'Citroen', 'C4', 'France');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (8, 'Peugeot', '306', 'France');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (9, 'Volvo', '850R', 'Italy');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (10, 'Nissan', 'Silvia S13', 'Japan');
INSERT INTO automobili(id, marka, model, drzava_porekla) VALUES (11, 'Honda', 'CRX', 'Japan');

ALTER TABLE automobili DROP COLUMN godina_proizvodnje;
ALTER TABLE automobili ADD godina_proizvodnje int;

INSERT INTO automobili(id, marka, model, drzava_porekla, godina_proizvodnje) VALUES (1, 'Mercedes-Benz', 'W126', 'Germany', '1979-1992');
INSERT INTO automobili(godina_proizvodnje) VALUES ('1979-1992'); 


SELECT * FROM korisnici WHERE first_name LIKE 'M%' ORDER BY first_name DESC;

DROP TABLE korisnici;

CREATE TABLE users (
	username varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	password varchar(255) NOT NULL
);

CREATE TABLE users_data (
	username varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	phone_number varchar(255) NOT NULL,
	address varchar(255) NOT NULL
);

INSERT INTO users_data(username, email, phone_number, address) VALUES ('themarekz', 'themarekz@live.com', '0642514570', 'Put za Crvenku 1 deo 17, Borca, Beograd');
