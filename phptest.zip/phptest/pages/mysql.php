<?php 

?>
<style>
<?php 
include 'CSS/main.css'; 
?>
</style>
<?php 

$username = "root";
$password = "";
$host = "localhost";
$dbname = "users";

$conn = mysqli_connect($host, $username, $password, $dbname);
if(!$conn) {
	die('Failed to connect to MySQL: ' . mysqli_connect_error());
}

$sql = 'SELECT * FROM automobili';

$querry = mysqli_query($conn, $sql);

if (!$querry) {
	die ('SQL Error: ' . mysqli_error($conn));
}

?>
<table>
	<tr>
		<th>ID</th>
		<th>Marka</th>
		<th>Model</th>
		<th>Drzava porekla</th>
	</tr>
<?php 
while ($row = mysqli_fetch_array($querry)) {
	echo "<tr>";
		echo "<td>" . $row['id'] . "</td>";
		echo "<td>" . $row['marka'] . "</td>";
		echo "<td>" . $row['model'] . "</td>";
		echo "<td>" . $row['drzava_porekla'] . "</td>";
	echo "</tr>";
}

 ?>

	
</table>







	


