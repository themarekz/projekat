<?php 
  /*session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }*/


?>
<!DOCTYPE html>
<html>
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="../css/main.css">
		<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	</head>
	<body>
		<div class="wrapper">
			<div class="navigation">
				<ul>
					<li><a href="#"><img src="../images/home.png" width="20px" height="20px"> Home</a></li>
					<li><a href="contact.html"><img src="../images/contact.png" width="20px" height="20px"> Contact</a></li>
					<li class="regLink"><a href="../registration/register.php" data-transition="	"><img src="../images/register.png" width="20px" height="20px"> Register </a></li>
					<li id="login"><a href="../registration/login.php"><img src="../images/login.png" width="20px" height="20px"> Login</a></li>
					<li id="products"><a href="../pages/products.html"><img src="../images/cart.png" width="20px" height="20px"> Products</a></li>
					<!-- <li><a href="../registration/register.php"">Logout</a></a></li> -->
					<!-- logged in user information -->
				    <?php  if (isset($_SESSION['username'])) : ?>
				    <!-- <li><a href="../registration/logout.php?logout='1'"">Logout</a></li> -->
				    <?php endif ?>
				</ul>
			</div>
		    <div class="hero-image">
		    	<div class="hero-text">

		    	</div>
		    <?php echo date("d/m/Y"); ?>
		    </div>
		</div>
			
	</body>
</html>
