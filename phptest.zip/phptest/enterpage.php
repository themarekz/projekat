<?php

include 'includes/functions.php';


 ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/another.css">
		<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	</head>
	<body id="body">
		<div class="container">

			<button id="myButton" class="float-left submit-button" >Click Me</button>
			<script type="text/javascript">
			    document.getElementById("myButton").onclick = function () {
			        location.href = "http://localhost/phptest/pages/home.php";
			    };
			</script>
		</div>
	</body>
</html>
			
