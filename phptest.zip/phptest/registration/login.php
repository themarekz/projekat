<?php include('server.php') ?>
<!DOCTYPE html>
<html>
    <head>
      <title>Login</title>
      <link rel="stylesheet" type="text/css" href="../css/main.css">
      <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    </head>
    <body>
      	<div class="wrapper">
          <div class="navigation">
            <ul>
              <li><a href="../pages/home.php"><img src="../images/home.png" width="20px" height="20px"> Home</a></li>
              <li><a href="../pages/contact.html"><img src="../images/contact.png" width="20px" height="20px"> Contact</a></li>
              <li class="regLink"><a href="../registration/register.php"><img src="../images/register.png" width="20px" height="20px"> Register </a>
              <li id="login"><a href="#"><img src="../images/login.png" width="20px" height="20px"> Login</a></li>
              <li id="products"><a href="../pages/products.html"><img src="../images/cart.png" width="20px" height="20px"> Products</a></li
            </ul>
          </div>
              <form name="forma" method="post" action="login.php">
                <fieldset>
                  <?php include('errors.php'); ?>
                  <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="username" >
                  </div>
                  <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password">
                  </div>
                  <div class="input-group">
                    <button type="submit" class="btn" name="login_user">Login</button>
                  </div>
                  <p>
                    <h1>Not yet a member?<a id="signUp" href="register.php"> Sign up</a></h1>
                  </p>
                </fieldset>
              </form>
        </div>
    </body>
</html>
                                
             
              