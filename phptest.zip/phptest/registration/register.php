<?php include('server.php') ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Registration</title>
		<link rel="stylesheet" type="text/css" href="../css/main.css">
		<script type="text/javascript"></script>
		<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	</head>
	<body>
		<div class="wrapper">
			<div class="navigation">
				<ul>
					<li><a href="../pages/home.php"><img src="../images/home.png" width="20px" height="20px"> Home</a></li>
					<li><a href="../pages/contact.html"><img src="../images/contact.png" width="20px" height="20px"> Contact</a></li>
					<li class="regLink"><a href="#"><img src="../images/register.png" width="20px" height="20px"> Register </a>
					<li id="login"><a href="../registration/login.php"><img src="../images/login.png" width="20px" height="20px"> Login</a></li>
					<li id="products"><a href="../pages/products.html"><img src="../images/cart.png" width="20px" height="20px"> Products</a></li>
				</ul>
			</div>
			<form method="post" action="register.php">
			<fieldset>
			<legend>Registration</legend>
				<?php include('errors.php') ?>
				<div class="input-group">
					<label>Username</label>
					<input type="text" name="username" value="<?php echo $username; ?>">
				</div>
				<div class="input-group">
					<label>Email</label>
					<input type="email" name="email" value="<?php echo $email; ?>">
				</div>
				<div class="input-group">
					<label>Password</label>
					<input type="password" name="password">
				</div>
				<div class="input-group">
					<label>Confirm password</label>
					<input type="password" name="password_2">
				</div>
				<div class="input-group">
					<button type="submit" class="btn" name="reg_user">Register</button>
				</div>
				<p>
					<h1>Already a member? <a href="login.php"> Sign in</a></h1>
				</p>
			</fieldset>
			</form>
		</div>
	</body>
</html>
			