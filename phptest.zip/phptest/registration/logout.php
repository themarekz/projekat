<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/main.css">
		<script type="text/javascript"></script>
	</head>
	<body>
		<div class="wrapper">
			<div class="navigation">
				<ul>
					<li><a href="../pages/home.html">Home</a></li>
					<li><a href="../pages/home.html">Contact</a></li>
					<li><a href="../registration/register.php">Register</a></li>
					<li id="login"><a href="login.php">Login</a></li>
					<!-- #logout -->
				</ul>
			</div>
		</div>
	</body>
</html>

